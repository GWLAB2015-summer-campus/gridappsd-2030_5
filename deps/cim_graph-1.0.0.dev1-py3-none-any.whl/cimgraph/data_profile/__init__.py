from enum import Enum

class CIM_PROFILE(Enum):
    CIMEXT_2022 = 'cimext_2022'
    RC4_2021 = 'rc4_2021'
    CIMHUB_2023 = 'cimhub_2023'